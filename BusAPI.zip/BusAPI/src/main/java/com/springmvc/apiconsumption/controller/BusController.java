package com.springmvc.apiconsumption.controller;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.springmvc.apiconsumption.model.Bus;
import com.springmvc.apiconsumption.model.BusRoute;

@Controller
public class BusController {
	
	@RequestMapping(value="/apiconsumption.html", method=RequestMethod.GET)
	public ModelAndView getBusForm() {
		ModelAndView model = new ModelAndView("search");
		return model;
	}
	
	
	/*
	 * @RequestMapping(value="/nextBus.html", method=RequestMethod.POST) //public
	 * ModelAndView submitBusForm(@RequestParam("busRoute") String
	 * busRoute, @RequestParam("busStop") String busStop, @RequestParam("direction")
	 * String direction) { public ModelAndView submitBusForm(@RequestParam
	 * Map<String,String> reqParam) {
	 * 
	 * String busRoute = reqParam.get("busRoute"); String busStop =
	 * reqParam.get("busStop"); String direction = reqParam.get("direction");
	 * 
	 * ModelAndView model = new ModelAndView("searchSuccessful");
	 * model.addObject("msg", "Bus Route " + busRoute + ",Bus Stop " + busStop +
	 * ",Direction " + direction); return model; }
	 */
	 
	
	
	@RequestMapping(value = "/nextBus.html", method = RequestMethod.POST)
	public ModelAndView submitBusForm(@ModelAttribute("busObj") Bus busObj) {

		System.out.println("1");
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("2");
		/*
		 * MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new
		 * MappingJackson2HttpMessageConverter();
		 * mappingJackson2HttpMessageConverter.setSupportedMediaTypes(Arrays.asList(
		 * MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM));
		 * restTemplate.getMessageConverters().add(mappingJackson2HttpMessageConverter);
		 */
		/*
		 * BusRoute[] busRouteObj = restTemplate.getForObject(
		 * "http://svc.metrotransit.org/NexTrip/Routes?format=json", BusRoute[].class);
		 * System.out.println("3");
		 * 
		 * ResponseEntity<BusRoute[]> responseEntity = restTemplate.getForEntity(
		 * "http://svc.metrotransit.org/NexTrip/Routes?format=json", BusRoute[].class);
		 * BusRoute[] busRouteObj1= responseEntity.getBody();
		 * 
		 * System.out.println(busRouteObj1[0].getDescription());
		 * 
		 * System.out.println("Object Length " + busRouteObj.length + " Object Content "
		 * + busRouteObj.toString());
		 * 
		 * int objLength = busRouteObj.length;
		 */

		//System.out.println("Value " + busRouteObj[0].getDescription());
		//System.out.println(Arrays.toString(busRouteObj));
		
		/*
		 * for (int i = 0; i < objLength; i++) {
		 * System.out.println(busRouteObj[i].getDescription());
		 * System.out.println(busRouteObj[i].getProviderID());
		 * System.out.println(busRouteObj[i].getRouteID()); }
		 */
		
		ResponseEntity<List<BusRoute>> rateResponse = restTemplate.exchange("http://svc.metrotransit.org/NexTrip/Routes?format=json", HttpMethod.GET, null, new ParameterizedTypeReference<List<BusRoute>>(){});
		List<BusRoute> busRoutes = rateResponse.getBody();
		System.out.println(rateResponse.getBody().size());
		//System.out.println(rateResponse.getBody().toString());
	
		
		for(BusRoute busRoutesLoop : busRoutes) {
			System.out.println(busRoutesLoop);
			System.out.println("Description: " + busRoutesLoop.getDescription());
			System.out.println("ProviderID: " + busRoutesLoop.getProviderID());
			System.out.println("Route: " + busRoutesLoop.getRoute());
			System.out.println("=========");
			
		}
		
		/*
		 * for (Iterator iterator = busRoutes.iterator(); iterator.hasNext();) {
		 * BusRoute busRoute = (BusRoute) iterator.next(); System.out.println(busRoute);
		 * }
		 */
		
		ModelAndView model = new ModelAndView("searchSuccessful");
		model.addObject("msg", "Information Retrieved");
		return model;
	}
	
}

package com.springmvc.apiconsumption.model;

public class BusRoute {
	
	/*
	 * public String getDescription() { return description; } public void
	 * setDescription(String description) { this.description = description; } public
	 * int getProviderID() { return providerID; } public void setProviderID(int
	 * providerID) { this.providerID = providerID; } public int getRouteID() {
	 * return routeID; } public void setRouteID(int routeID) { this.routeID =
	 * routeID; }
	 * 
	 * private String description;
	 * 
	 * private int providerID;
	 * 
	 * private int routeID;
	 */
	
	private String Description;
	private String ProviderID;
	private String Route;
	
	
	
	/*
	 * public BusRoute(String description, String providerID, String route) {
	 * super(); Description = description; ProviderID = providerID; Route = route; }
	 */
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getProviderID() {
		return ProviderID;
	}
	public void setProviderID(String providerID) {
		ProviderID = providerID;
	}
	public String getRoute() {
		return Route;
	}
	public void setRoute(String route) {
		Route = route;
	}


}
